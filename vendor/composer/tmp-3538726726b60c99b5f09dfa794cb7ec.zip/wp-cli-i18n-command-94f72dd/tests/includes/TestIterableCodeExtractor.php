<?php

namespace WP_CLI\I18n\Tests;

use WP_CLI\I18n\IterableCodeExtractor;

class TestIterableCodeExtractor {
	use IterableCodeExtractor;
}
