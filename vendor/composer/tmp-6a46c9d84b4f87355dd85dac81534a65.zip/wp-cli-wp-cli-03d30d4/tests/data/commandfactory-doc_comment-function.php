<?php

/**
 * foo
 */
function commandfactorytests_get_doc_comment_func_1( $function = blah ) {
}

/**
 * bar
 function*/function commandfactorytests_get_doc_comment_func_2( $function = blah ) {
}

/**
 * /** baz
 */$commandfactorytests_get_doc_comment_func_3
  =
  	function ( $args ) {
};
